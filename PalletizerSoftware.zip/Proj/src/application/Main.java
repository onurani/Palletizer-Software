package application;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;


public class Main extends Application {

    private double boxWidth;
    private double boxHeight;
    private double boxDepth;
    private double palletWidth;
    private double palletHeight;
    private double palletDepth;
    private int numberOfLayers;
    private int numberOfSlipsheets;

    
    @Override
    public void start(Stage primaryStage) {
        try {
            TabPane tabPane = new TabPane();

            // Adding Pallet Setup
            Tab palletSetupTab = new Tab("Pallet Setup");
            PalletSetup palletSetup = new PalletSetup("Pallet Setup", this);
            palletSetupTab.setContent(palletSetup);
            tabPane.getTabs().add(palletSetupTab);

            
            // Adding Infeed Stations
            for (int i = 1; i <= 8; i++) {
                Tab tab = new Tab("Infeed Station " + i);
                InfeedStation infeedStation = new InfeedStation("Infeed Station " + i);
                tab.setContent(infeedStation);
                tabPane.getTabs().add(tab);
            }
            
            // Adding Build Stations
            for (int i = 1; i <= 8; i++) {
                Tab tab = new Tab("Build Station " + i);
                BuildStation buildStation = new BuildStation("Build Station " + i, this);
                tab.setContent(buildStation);
                tabPane.getTabs().add(tab);
            }

         

            // Adding User Frames (Placeholder)
            for (int i = 17; i <= 63; i++) {
                Tab tab = new Tab("User Frame " + i);
                tab.setContent(new Label("Placeholder for User Frame " + i));
                tabPane.getTabs().add(tab);
            }

            Scene scene = new Scene(tabPane, 800, 600);
            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

            primaryStage.setScene(scene);
            primaryStage.setTitle("Palletizer Application");
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void setBoxDimensions(double width, double height, double depth) {
        this.boxWidth = width;
        this.boxHeight = height;
        this.boxDepth = depth;
    }

    public void setPalletDimensions(double width, double height, double depth) {
        this.palletWidth = width;
        this.palletHeight = height;
        this.palletDepth = depth;
    }
    
    public void setNumberOfLayers(int numberOfLayers) {
        this.numberOfLayers = numberOfLayers;
    }

    public void setNumberOfSlipsheets(int numberOfSlipsheets) {
        this.numberOfSlipsheets = numberOfSlipsheets;
    }

    public double getBoxWidth() {
        return boxWidth;
    }

    public double getBoxHeight() {
        return boxHeight;
    }

    public double getBoxDepth() {
        return boxDepth;
    }

    public double getPalletWidth() {
        return palletWidth;
    }

    public double getPalletHeight() {
        return palletHeight;
    }

    public double getPalletDepth() {
        return palletDepth;
    }
    
    public int getNumberOfLayers() {
        return numberOfLayers;
    }

    public int getNumberOfSlipsheets() {
        return numberOfSlipsheets;
    }

    public static void main(String[] args) {
        launch(args);
    }
}


/*
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Palletizer Application");

        // Create tabs for each station type
        TabPane tabPane = new TabPane();

        // Create and add Pallet Setup Tab
        Tab palletSetupTab = new Tab("Pallet Setup");
        PalletSetup palletSetup = new PalletSetup();
        palletSetupTab.setContent(palletSetup.getPane());
        tabPane.getTabs().add(palletSetupTab);

        // Create and add Infeed Station Tabs
        for (int i = 1; i <= 8; i++) {
            Tab infeedTab = new Tab("Infeed Station " + i);
            InfeedStation infeedStation = new InfeedStation(i);
            infeedTab.setContent(infeedStation.getPane());
            tabPane.getTabs().add(infeedTab);
        }

        // Create and add Build Station Tabs
        for (int i = 1; i <= 8; i++) {
            Tab buildStationTab = new Tab("Build Station " + i);
            BuildStation buildStation = new BuildStation(i);
            buildStationTab.setContent(buildStation.getPane());
            tabPane.getTabs().add(buildStationTab);
        }

        // Add placeholder tabs if needed
        for (int i = 1; i <= 64 - 17; i++) {
            Tab placeholderTab = new Tab("Placeholder " + i);
            VBox placeholderPane = new VBox();
            placeholderTab.setContent(placeholderPane);
            tabPane.getTabs().add(placeholderTab);
        }

        Scene scene = new Scene(tabPane, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
*/
