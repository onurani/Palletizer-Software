package application;

public class Box {
    private double width;
    private double depth;
    private double height;

    public Box(double width, double depth, double height) {
        this.width = width;
        this.depth = depth;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public double getDepth() {
        return depth;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return String.format("Box [width=%.2f, depth=%.2f, height=%.2f]", width, depth, height);
    }
}


/*
 * so given these codes: package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.List;

public class BuildStation extends GridPane {

    private List<TextField> numBoxesFields; // List of TextFields for number of boxes per layer
    private List<List<BoxInput>> boxInputs; // List of Lists for box position inputs
    private Label statusLabel;
    private Button startButton;
    private Main mainApp;
    private int layer;

    private static final double GAP_SIZE = 0.5; // Define gap size in millimeters

    private List<BoxPosition> placedBoxes; // List to track placed boxes
    private Pane palletPane; // Pane to visualize the pallet and boxes

    public BuildStation(String stationName, Main mainApp) {
        this.mainApp = mainApp;

        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        Label stationLabel = new Label(stationName);
        stationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        numBoxesFields = new ArrayList<>();
        boxInputs = new ArrayList<>();
        for (int i = 0; i < 8; i++) { // Max 8 layers
            TextField numBoxesField = new TextField("1");
            numBoxesFields.add(numBoxesField);
            add(new Label("Number of Boxes in Layer " + (i + 1) + ":"), 0, i + 1);
            add(numBoxesField, 1, i + 1);

            List<BoxInput> layerBoxInputs = new ArrayList<>();
            boxInputs.add(layerBoxInputs);
        }

        startButton = new Button("Set Box Positions");
        startButton.setOnAction(e -> showBoxInputFields());

        Button buildButton = new Button("Start Building");
        buildButton.setOnAction(e -> handleStartBuilding());

        statusLabel = new Label("Waiting to start...");

        add(stationLabel, 0, 0, 2, 1);
        add(startButton, 0, 9, 2, 1);
        add(buildButton, 0, 10, 2, 1);
        add(statusLabel, 0, 11, 2, 1);

        placedBoxes = new ArrayList<>(); // Initialize the list

        palletPane = new Pane();
        palletPane.setStyle("-fx-background-color: lightgray;");
        palletPane.setPrefSize(500, 500); // Adjust as needed

        add(palletPane, 2, 0, 4, 12);
    }

    private void showBoxInputFields() {
        for (layer = 0; layer < numBoxesFields.size(); layer++) {
            int numBoxes = Integer.parseInt(numBoxesFields.get(layer).getText());
            List<BoxInput> layerBoxInputs = boxInputs.get(layer);

            // Clear previous inputs
            layerBoxInputs.clear();
            getChildren().removeIf(node -> GridPane.getRowIndex(node) == 12 + layer);

            for (int box = 0; box < numBoxes; box++) {
                BoxInput boxInput = new BoxInput();
                layerBoxInputs.add(boxInput);
                add(new Label("Layer " + (layer + 1) + ", Box " + (box + 1) + " (x, y):"), 0, 12 + layer + box);
                add(boxInput.xField, 1, 12 + layer + box);
                add(boxInput.yField, 2, 12 + layer + box);
            }
        }
    }

    private void handleStartBuilding() {
        try {
            double boxWidth = mainApp.getBoxWidth();
            double boxHeight = mainApp.getBoxHeight();
            double boxDepth = mainApp.getBoxDepth();
            double palletWidth = mainApp.getPalletWidth();
            double palletHeight = mainApp.getPalletHeight();
            double palletDepth = mainApp.getPalletDepth();

            // Clear previous placements
            placedBoxes.clear();
            palletPane.getChildren().clear(); // Clear previous visualizations

            // Generate the pattern for box placement
            StringBuilder pattern = new StringBuilder("Pattern:\n");

            for (int layer = 0; layer < numBoxesFields.size(); layer++) {
                List<BoxInput> layerBoxInputs = boxInputs.get(layer);

                for (BoxInput boxInput : layerBoxInputs) {
                    double x = Double.parseDouble(boxInput.xField.getText());
                    double y = Double.parseDouble(boxInput.yField.getText());

                    // Check for collisions with already placed boxes
                    if (!isColliding(x, y, boxWidth, boxHeight)) {
                        placedBoxes.add(new BoxPosition(x, y, boxWidth, boxHeight));
                        pattern.append(String.format("Layer %d, Box: (%.2f, %.2f)\n", layer + 1, x, y));
                        
                        // Visualize the box
                        Rectangle boxRect = new Rectangle(x, y, boxWidth, boxHeight);
                        boxRect.setFill(Color.BLUE);
                        boxRect.setStroke(Color.BLACK);
                        palletPane.getChildren().add(boxRect);
                    } else {
                        statusLabel.setText("Collision detected, adjust placement or box dimensions.");
                        return;
                    }
                }
            }

            statusLabel.setText(pattern.toString());

            // Communicate the pattern to the robot for execution
            sendPatternToRobot(pattern.toString());

        } catch (NumberFormatException e) {
        	
            statusLabel.setText("Invalid input. Please enter valid numbers for box positions.");
        } catch (IllegalArgumentException e) {
            statusLabel.setText(e.getMessage());
        }
    }

    private boolean isColliding(double x, double y, double width, double height) {
        for (BoxPosition box : placedBoxes) {
            if (Math.abs(box.x - x) < (width + box.width) / 2 + GAP_SIZE &&
                Math.abs(box.y - y) < (height + box.height) / 2 + GAP_SIZE) {
                return true;
            }
        }
        return false;
    }

    private void sendPatternToRobot(String pattern) {
        // Implement the logic to send the generated pattern to the robot for execution
        System.out.println("Sending pattern to robot:");
        System.out.println(pattern);
    }

    // Inner class to represent the position and dimensions of a placed box
    private static class BoxPosition {
        double x, y;
        double width, height;

        BoxPosition(double x, double y, double width, double height) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }
    }

    // Inner class to represent the input fields for box positions
    private static class BoxInput {
        TextField xField;
        TextField yField;

        BoxInput() {
            xField = new TextField();
            yField = new TextField();
        }
    }
}                                                                                                                                                                  package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class InfeedStation extends GridPane {

    private TextField clearanceHeight;
    private TextField apprPickHeight;
    private TextField departPickHeight;
    private Label setupStatus;
    private Rectangle statusIndicator;
    private Button abortButton;
    private Button lockButton;
    private Button unlockButton;
    private Button pickupReadyButton;
    private Button inactiveButton;
    private Button markSetupCompleteButton;
    
    private Button markSetupNotCompleteButton;

    // Properties to store the values
    private double clearanceHeightValue;
    private double apprPickHeightValue;
    private double departPickHeightValue;
    private boolean isSetupComplete;

    public InfeedStation(String stationName) {
        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        Label stationLabel = new Label(stationName);
        stationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        statusIndicator = new Rectangle(15, 15, Color.RED);

        abortButton = new Button("Abort");
        abortButton.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        abortButton.setOnAction(e -> handleAbort());

        Label servosLabel = new Label("ServosOffReady");
        servosLabel.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        setupStatus = new Label("Setup Not Complete");
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");

        clearanceHeight = new TextField("500.0");
        apprPickHeight = new TextField("200.0");
        departPickHeight = new TextField("100.0");

        markSetupCompleteButton = new Button("Mark Setup Complete");
        markSetupCompleteButton.setOnAction(e -> markSetupComplete());

        markSetupNotCompleteButton = new Button("Mark Setup Not Complete");
        markSetupNotCompleteButton.setOnAction(e -> markSetupNotComplete());

        lockButton = new Button("Lock Infeed");
        lockButton.setOnAction(e -> handleLockInfeed());

        unlockButton = new Button("Unlock Infeed");
        unlockButton.setOnAction(e -> handleUnlockInfeed());

        pickupReadyButton = new Button("Pickup Ready");
        pickupReadyButton.setOnAction(e -> handlePickupReady());

        inactiveButton = new Button("Infeed Not Active");
        inactiveButton.setOnAction(e -> handleInactive());

        add(stationLabel, 0, 0, 2, 1);
        add(statusIndicator, 2, 0);
        add(abortButton, 3, 0);
        add(servosLabel, 4, 0);

        add(new Label("Clearance Height"), 0, 1);
        add(clearanceHeight, 1, 1);

        add(new Label("Appr Pick 1 Height"), 2, 1);
        add(apprPickHeight, 3, 1);

        add(new Label("Depart Pick 1 Height"), 4, 1);
        add(departPickHeight, 5, 1);

        add(setupStatus, 0, 2, 2, 1);
        add(markSetupCompleteButton, 2, 2);
        add(markSetupNotCompleteButton, 3, 2);

        add(lockButton, 0, 3);
        add(unlockButton, 1, 3);
        add(pickupReadyButton, 2, 3);
        add(inactiveButton, 3, 3);
    }

    private void markSetupComplete() {
        try {
            clearanceHeightValue = Double.parseDouble(clearanceHeight.getText());
            apprPickHeightValue = Double.parseDouble(apprPickHeight.getText());
            departPickHeightValue = Double.parseDouble(departPickHeight.getText());

            setupStatus.setText("Setup Complete");
            setupStatus.setStyle("-fx-background-color: green; -fx-text-fill: white;");
            statusIndicator.setFill(Color.GREEN);

            isSetupComplete = true;

            // Communicate with the robot to update its settings
            updateRobotSettings();

        } catch (NumberFormatException e) {
            setupStatus.setText("Invalid Input");
            setupStatus.setStyle("-fx-background-color: orange; -fx-text-fill: white;");
            statusIndicator.setFill(Color.ORANGE);
        }
    }

    private void markSetupNotComplete() {
        setupStatus.setText("Setup Not Complete");
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        statusIndicator.setFill(Color.RED);

        isSetupComplete = false;

        // Communicate with the robot to reset its settings
        resetRobotSettings();
    }

    private void handleAbort() {
        clearanceHeight.setText("500.0"); // Reset clearance height
        apprPickHeight.setText("200.0"); // Reset approach pick height
        departPickHeight.setText("100.0"); // Reset depart pick height

        setupStatus.setText("Setup Not Complete"); // Reset setup status
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        statusIndicator.setFill(Color.RED); // Reset status indicator

        isSetupComplete = false;

        // Communicate with the robot to abort its current operations
        abortRobotOperations();
    }

    private void handleLockInfeed() {
        //Implement behavior for locking the infeed
        System.out.println("Lock Infeed button clicked.");

        //Add code to communicate with the robot to lock the infeed
    }

    private void handleUnlockInfeed() {
        //Implement behavior for unlocking the infeed
        System.out.println("Unlock Infeed button clicked.");
        //Add code to communicate with the robot to unlock the infeed
    }

    private void handlePickupReady() {
        //Implement behavior for indicating pickup readiness
        System.out.println("Pickup Ready button clicked.");
        //Add code to communicate with the robot to indicate pickup readiness
    }

    private void handleInactive() {
        //Implement behavior for indicating inactivity
        System.out.println("Infeed Not Active button clicked.");
        //Add code to communicate with the robot to indicate inactivity
    }

    private void updateRobotSettings() {
        // Implement the logic to update the robot's settings with the provided values
        System.out.println("Updating robot settings:");
        System.out.println("Clearance Height: " + clearanceHeightValue);
        System.out.println("Approach Pick 1 Height: " + apprPickHeightValue);
        System.out.println("Depart Pick 1 Height: " + departPickHeightValue);
    }

    private void resetRobotSettings() {
        // Implement the logic to reset the robot's settings
        System.out.println("Resetting robot settings to default values.");
    }

    private void abortRobotOperations() {
        // Implement the logic to abort the robot's current operations
        // You may need to call the specific API methods to stop the robot
        System.out.println("Aborting robot operations and resetting settings.");
        
        // Example commands to stop the robot (adjust based on your actual API)
        try {
            // Assuming a Controller class with a static abort method
           // Controller.abort(controllerID); // Replace controllerID with the actual ID
            System.out.println("Robot operations aborted successfully.");
        } catch (Exception e) {
            System.out.println("Failed to abort robot operations: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public double getClearanceHeightValue() {
        if (apprPickHeightValue < clearanceHeightValue) {
            return clearanceHeightValue;
        } else {
            return 0.0;
        }
    }

    public double getApprPickHeightValue() {
        return apprPickHeightValue;
    }

    public double getDepartPickHeightValue() {
        return departPickHeightValue;
    }

    public boolean isSetupComplete() {
        return isSetupComplete;
    }
    
}
package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

public class Main extends Application {

    private double boxWidth;
    private double boxHeight;
    private double boxDepth;
    private double palletWidth;
    private double palletHeight;
    private double palletDepth;

    @Override
    public void start(Stage primaryStage) {
        try {
            TabPane tabPane = new TabPane();

            // Adding Pallet Setup
            Tab palletSetupTab = new Tab("Pallet Setup");
            PalletSetup palletSetup = new PalletSetup("Pallet Setup", this);
            palletSetupTab.setContent(palletSetup);
            tabPane.getTabs().add(palletSetupTab);

            // Adding Infeed Stations
            for (int i = 1; i <= 8; i++) {
                Tab tab = new Tab("Infeed Station " + i);
                InfeedStation infeedStation = new InfeedStation("Infeed Station " + i);
                tab.setContent(infeedStation);
                tabPane.getTabs().add(tab);
            }

            // Adding Build Stations
            for (int i = 1; i <= 8; i++) {
                Tab tab = new Tab("Build Station " + i);
                BuildStation buildStation = new BuildStation("Build Station " + i, this);
                tab.setContent(buildStation);
                tabPane.getTabs().add(tab);
            }

            // Adding User Frames (Placeholder)
            for (int i = 17; i <= 63; i++) {
                Tab tab = new Tab("User Frame " + i);
                tab.setContent(new Label("Placeholder for User Frame " + i));
                tabPane.getTabs().add(tab);
            }

            Scene scene = new Scene(tabPane, 800, 600);
            scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());

            primaryStage.setScene(scene);
            primaryStage.setTitle("Robot Arm Controller");
            primaryStage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void setBoxDimensions(double width, double height, double depth) {
        this.boxWidth = width;
        this.boxHeight = height;
        this.boxDepth = depth;
    }

    public void setPalletDimensions(double width, double height, double depth) {
        this.palletWidth = width;
        this.palletHeight = height;
        this.palletDepth = depth;
    }

    public double getBoxWidth() {
        return boxWidth;
    }

    public double getBoxHeight() {
        return boxHeight;
    }

    public double getBoxDepth() {
        return boxDepth;
    }

    public double getPalletWidth() {
        return palletWidth;
    }

    public double getPalletHeight() {
        return palletHeight;
    }

    public double getPalletDepth() {
        return palletDepth;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class PalletSetup extends GridPane {

    private TextField boxWidthField;
    private TextField boxHeightField;
    private TextField boxDepthField;
    private TextField palletWidthField;
    private TextField palletHeightField;
    private TextField palletDepthField;
    private Label statusLabel;
    private Button saveButton;
    private Main mainApp;

    public PalletSetup(String title, Main mainApp) {
        this.mainApp = mainApp;

        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        boxWidthField = new TextField();
        boxHeightField = new TextField();
        boxDepthField = new TextField();
        palletWidthField = new TextField();
        palletHeightField = new TextField();
        palletDepthField = new TextField();

        saveButton = new Button("Save Setup");
        saveButton.setOnAction(e -> handleSaveSetup());

        statusLabel = new Label();

        add(titleLabel, 0, 0, 2, 1);
        add(new Label("Box Width:"), 0, 1);
        add(boxWidthField, 1, 1);
        add(new Label("Box Height:"), 0, 2);
        add(boxHeightField, 1, 2);
        add(new Label("Box Depth:"), 0, 3);
        add(boxDepthField, 1, 3);
        add(new Label("Pallet Width:"), 0, 4);
        add(palletWidthField, 1, 4);
        add(new Label("Pallet Height:"), 0, 5);
        add(palletHeightField, 1, 5);
        add(new Label("Pallet Depth:"), 0, 6);
        add(palletDepthField, 1, 6);
        add(saveButton, 0, 7, 2, 1);
        add(statusLabel, 0, 8, 2, 1);
    }

    private void handleSaveSetup() {
        try {
            double boxWidth = Double.parseDouble(boxWidthField.getText());
            double boxHeight = Double.parseDouble(boxHeightField.getText());
            double boxDepth = Double.parseDouble(boxDepthField.getText());
            double palletWidth = Double.parseDouble(palletWidthField.getText());
            double palletHeight = Double.parseDouble(palletHeightField.getText());
            double palletDepth = Double.parseDouble(palletDepthField.getText());

            mainApp.setBoxDimensions(boxWidth, boxHeight, boxDepth);
            mainApp.setPalletDimensions(palletWidth, palletHeight, palletDepth);

            statusLabel.setText("Setup saved successfully.");

        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid input. Please enter valid numbers.");
        }
    }
}
package application;

public class Box {
    private double width;
    private double depth;
    private double height;

    public Box(double width, double depth, double height) {
        this.width = width;
        this.depth = depth;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public double getDepth() {
        return depth;
    }

    public double getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return String.format("Box [width=%.2f, depth=%.2f, height=%.2f]", width, depth, height);
 } }
 */
