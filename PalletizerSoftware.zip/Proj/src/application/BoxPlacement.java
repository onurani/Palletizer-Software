package application;

import java.util.ArrayList;
import java.util.List;

public class BoxPlacement {
    private double boxWidth;
    private double boxHeight;
    private double palletWidth;
    private double palletHeight;
    private List<PlacedBox> placedBoxes;

    public BoxPlacement(double boxWidth, double boxHeight, double palletWidth, double palletHeight) {
        this.boxWidth = boxWidth;
        this.boxHeight = boxHeight;
        this.palletWidth = palletWidth;
        this.palletHeight = palletHeight;
        this.placedBoxes = new ArrayList<>();
    }

    public boolean placeBox(double x, double y) {
        if (x < 0 || y < 0 || x + boxWidth > palletWidth || y + boxHeight > palletHeight) {
            return false; // Out of bounds
        }

        for (PlacedBox placedBox : placedBoxes) {
            if (boxesOverlap(placedBox, x, y)) {
                return false; // Collision detected
            }
        }

        placedBoxes.add(new PlacedBox(x, y));
        return true;
    }

    private boolean boxesOverlap(PlacedBox placedBox, double x, double y) {
        return !(x + boxWidth <= placedBox.x || x >= placedBox.x + boxWidth ||
                 y + boxHeight <= placedBox.y || y >= placedBox.y + boxHeight);
    }

    private static class PlacedBox {
        double x, y;

        PlacedBox(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }
}
