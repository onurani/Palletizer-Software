package application;


import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class InfeedStation extends GridPane {

    private TextField clearanceHeight;
    private TextField apprPickHeight;
    private TextField departPickHeight;
    private Label setupStatus;
    private Rectangle statusIndicator;
    private Button abortButton;
    private Button lockButton;
    private Button unlockButton;
    private Button pickupReadyButton;
    private Button inactiveButton;
    private Button markSetupCompleteButton;
    
    private Button markSetupNotCompleteButton;
    private RobotController robotController;

    // Properties to store the values
    private double clearanceHeightValue;
    private double apprPickHeightValue;
    private double departPickHeightValue;
    private boolean isSetupComplete;

    public InfeedStation(String stationName) {
    	this.robotController = new RobotController(); // Initialize RobotController
    	
        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        Label stationLabel = new Label(stationName);
        stationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        statusIndicator = new Rectangle(15, 15, Color.RED);

        abortButton = new Button("Abort");
        abortButton.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        abortButton.setOnAction(e -> handleAbort());

        Label servosLabel = new Label("ServosOffReady");
        servosLabel.setStyle("-fx-background-color: black; -fx-text-fill: white;");

        setupStatus = new Label("Setup Not Complete");
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");

        clearanceHeight = new TextField("500.0");
        apprPickHeight = new TextField("200.0");
        departPickHeight = new TextField("100.0");

        markSetupCompleteButton = new Button("Mark Setup Complete");
        markSetupCompleteButton.setOnAction(e -> markSetupComplete());

        markSetupNotCompleteButton = new Button("Mark Setup Not Complete");
        markSetupNotCompleteButton.setOnAction(e -> markSetupNotComplete());

        lockButton = new Button("Lock Infeed");
        lockButton.setOnAction(e -> handleLockInfeed());

        unlockButton = new Button("Unlock Infeed");
        unlockButton.setOnAction(e -> handleUnlockInfeed());

        pickupReadyButton = new Button("Pickup Ready");
        pickupReadyButton.setOnAction(e -> handlePickupReady());

        inactiveButton = new Button("Infeed Not Active");
        inactiveButton.setOnAction(e -> handleInactive());

        add(stationLabel, 0, 0, 2, 1);
        add(statusIndicator, 2, 0);
        add(abortButton, 3, 0);
        add(servosLabel, 4, 0);

        add(new Label("Clearance Height"), 0, 1);
        add(clearanceHeight, 1, 1);

        add(new Label("Appr Pick 1 Height"), 2, 1);
        add(apprPickHeight, 3, 1);

        add(new Label("Depart Pick 1 Height"), 4, 1);
        add(departPickHeight, 5, 1);

        add(setupStatus, 0, 2, 2, 1);
        add(markSetupCompleteButton, 2, 2);
        add(markSetupNotCompleteButton, 3, 2);

        add(lockButton, 0, 3);
        add(unlockButton, 1, 3);
        add(pickupReadyButton, 2, 3);
        add(inactiveButton, 3, 3);
    }

    private void markSetupComplete() {
        try {
            clearanceHeightValue = Double.parseDouble(clearanceHeight.getText());
            apprPickHeightValue = Double.parseDouble(apprPickHeight.getText());
            departPickHeightValue = Double.parseDouble(departPickHeight.getText());

            setupStatus.setText("Setup Complete");
            setupStatus.setStyle("-fx-background-color: green; -fx-text-fill: white;");
            statusIndicator.setFill(Color.GREEN);

            isSetupComplete = true;

            // Communicate with the robot to update its settings
            robotController.updateSettings(clearanceHeightValue, apprPickHeightValue, departPickHeightValue);

        } catch (NumberFormatException e) {
            setupStatus.setText("Invalid Input");
            setupStatus.setStyle("-fx-background-color: orange; -fx-text-fill: white;");
            statusIndicator.setFill(Color.ORANGE);
        }
    }
    
    private void markSetupNotComplete() {
        setupStatus.setText("Setup Not Complete");
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        statusIndicator.setFill(Color.RED);

        isSetupComplete = false;

        // Communicate with the robot to reset its settings
        resetRobotSettings();
    }

    private void handleAbort() {
        clearanceHeight.setText("500.0"); // Reset clearance height
        apprPickHeight.setText("200.0"); // Reset approach pick height
        departPickHeight.setText("100.0"); // Reset depart pick height

        setupStatus.setText("Setup Not Complete"); // Reset setup status
        setupStatus.setStyle("-fx-background-color: red; -fx-text-fill: white;");
        statusIndicator.setFill(Color.RED); // Reset status indicator

        isSetupComplete = false;

        // Communicate with the robot to abort its current operations
        robotController.abortOperations();
    }

    private void handleLockInfeed() {
        //Implement behavior for locking the infeed
        System.out.println("Lock Infeed button clicked.");

        //Add code to communicate with the robot to lock the infeed
    }

    private void handleUnlockInfeed() {
        //Implement behavior for unlocking the infeed
        System.out.println("Unlock Infeed button clicked.");
        //Add code to communicate with the robot to unlock the infeed
    }

    private void handlePickupReady() {
        //Implement behavior for indicating pickup readiness
        System.out.println("Pickup Ready button clicked.");
        //Add code to communicate with the robot to indicate pickup readiness
    }

    private void handleInactive() {
        //Implement behavior for indicating inactivity
        System.out.println("Infeed Not Active button clicked.");
        //Add code to communicate with the robot to indicate inactivity
    }

    //pretty useless
    private void updateRobotSettings() {
        // Implement the logic to update the robot's settings with the provided values
        System.out.println("Updating robot settings:");
        System.out.println("Clearance Height: " + clearanceHeightValue);
        System.out.println("Approach Pick 1 Height: " + apprPickHeightValue);
        System.out.println("Depart Pick 1 Height: " + departPickHeightValue);
    }

    private void resetRobotSettings() {
        // Implement the logic to reset the robot's settings
        System.out.println("Resetting robot settings to default values.");
    }

    private void abortRobotOperations() {
        // Implement the logic to abort the robot's current operations
        // You may need to call the specific API methods to stop the robot
        System.out.println("Aborting robot operations and resetting settings.");
        
        // Example commands to stop the robot (adjust based on your actual API)
        try {
            // Assuming a Controller class with a static abort method
           // Controller.abort(controllerID); // Replace controllerID with the actual ID
            System.out.println("Robot operations aborted successfully.");
        } catch (Exception e) {
            System.out.println("Failed to abort robot operations: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public double getClearanceHeightValue() {
        if (apprPickHeightValue < clearanceHeightValue) {
            return clearanceHeightValue;
        } else {
            return 0.0;
        }
    }

    public double getApprPickHeightValue() {
        return apprPickHeightValue;
    }

    public double getDepartPickHeightValue() {
        return departPickHeightValue;
    }

    public boolean isSetupComplete() {
        return isSetupComplete;
    }
    
}


/*
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class InfeedStation {
    private VBox pane;
    private int stationId;
    private TextField speedField; // Example field for infeed settings

    public InfeedStation(int stationId) {
        this.stationId = stationId;
        pane = new VBox();

        speedField = new TextField();

        pane.getChildren().addAll(
            new Label("Infeed Station " + stationId + " Settings:"),
            new Label("Speed:"), speedField
            // Add more fields as needed
        );
    }

    public VBox getPane() {
        return pane;
    }

    // Add other methods to handle infeed station settings
}
*/