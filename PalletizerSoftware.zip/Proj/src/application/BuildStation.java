package application;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;
import javafx.scene.input.TouchEvent;

import java.util.ArrayList;
import java.util.List;

public class BuildStation extends GridPane {

    private List<TextField> numBoxesFields; // Number of boxes per layer
    private List<List<BoxInput>> boxInputs; // Box position inputs
    private Label statusLabel;
    private Button startButton;
    private Button buildButton;
    private Button addBoxButton; // Add a box to the current layer
    private Button addLayerButton; // Add new layer
    private Button finishLayerButton; // Finish the current layer
    private Button confirmButton; // Confirm box placements
    private TextField gapSizeField;
    private static final double DEFAULT_GAP_SIZE = 0.1; // Default gap size in millimeters
    private double gapSize = DEFAULT_GAP_SIZE;
    private List<List<BoxPosition>> placedBoxesPerLayer; // List of placed boxes for each layer
    private Pane palletPane; // Pane to visualize the pallet and boxes
    private Main mainApp;
    private RobotController robotController;
    private int currentLayer;
    private boolean isBuilding;

    public BuildStation(String stationName, Main mainApp) {
        this.mainApp = mainApp;
        this.robotController = new RobotController(); // Initialize RobotController

        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        // Set up layout panes
        VBox leftPane = new VBox(10);
        VBox rightPane = new VBox(10);
        rightPane.setPadding(new Insets(10));

        add(leftPane, 0, 0);
        add(rightPane, 1, 0);

        Label stationLabel = new Label(stationName);
        stationLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        numBoxesFields = new ArrayList<>();
        boxInputs = new ArrayList<>();
        
        // Initialize with no predefined layers
        placedBoxesPerLayer = new ArrayList<>();
        currentLayer = -1; // Start with no layers

        startButton = new Button("Start Building");
        startButton.setOnAction(e -> handleStartBuilding());

        addBoxButton = new Button("Add Box");
        addBoxButton.setOnAction(e -> addBox());

        addLayerButton = new Button("Add Layer");
        addLayerButton.setOnAction(e -> addLayer());

        finishLayerButton = new Button("Finish Layer");
        finishLayerButton.setOnAction(e -> finishLayer());

        confirmButton = new Button("Confirm");
        confirmButton.setOnAction(e -> confirmPlacements());

        statusLabel = new Label("Waiting to start...");

        leftPane.getChildren().addAll(startButton, addBoxButton, addLayerButton, finishLayerButton, confirmButton, statusLabel);

        palletPane = new Pane();
        palletPane.setStyle("-fx-background-color: lightgray;");
        //palletPane.setPrefSize(500, 500); // Adjust as needed

        add(palletPane, 2, 0, 4, 12);

        // Add a field for gap size input
        Label gapSizeLabel = new Label("Gap Size Between Boxes (mm):");
        gapSizeField = new TextField();
        gapSizeField.setPromptText("Enter gap size or leave blank for default");

        leftPane.getChildren().addAll(gapSizeLabel, gapSizeField);

        isBuilding = false;

        // Setup touch and mouse event handling
        setupTouchAndDragEvents();  
    }
    
    private void setupTouchAndDragEvents() {
        palletPane.setOnMousePressed(event -> handlePress(event));
        palletPane.setOnMouseDragged(event -> handleDrag(event));
        palletPane.setOnTouchPressed(event -> handleTouch(event));
        palletPane.setOnTouchMoved(event -> handleTouch(event));
    }
    
    

    private void handleStartBuilding() {
        try {
            double boxWidth = mainApp.getBoxWidth();
            double boxHeight = mainApp.getBoxHeight(); // Not used
            double boxDepth = mainApp.getBoxDepth();
            double palletWidth = mainApp.getPalletWidth();
            double palletHeight = mainApp.getPalletHeight(); // Not used
            double palletDepth = mainApp.getPalletDepth();

            // Get the user-defined gap size, default to 0.1 mm if not specified
            try {
                gapSize = gapSizeField.getText().isEmpty() ? DEFAULT_GAP_SIZE : Double.parseDouble(gapSizeField.getText());
                if (gapSize < 0) throw new NumberFormatException(); // Ensure non-negative gap size
            } catch (NumberFormatException e) {
                statusLabel.setText("Invalid gap size. Using default value of 0.1 mm.");
                gapSize = DEFAULT_GAP_SIZE;
            }
            
         // Adjust the palletPane size based on the user input
            palletPane.setPrefSize(palletWidth, palletDepth);

            // Initialize the list for placed boxes
            placedBoxesPerLayer.clear();
            isBuilding = true;
            statusLabel.setText("Start adding layers and boxes.");
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid input. Please enter valid numbers.");
        }
    }

    private void addBox() {
        if (!isBuilding) {
            statusLabel.setText("Start building before adding boxes.");
            return;
        }

        double boxWidth = mainApp.getBoxWidth();
        double boxDepth = mainApp.getBoxDepth();
        double palletWidth = mainApp.getPalletWidth();
        double palletDepth = mainApp.getPalletDepth();

        if (currentLayer < 0 || currentLayer >= placedBoxesPerLayer.size()) {
            statusLabel.setText("Add a layer before adding boxes.");
            return;
        }
        
    //    double z = Math.random() * palletDepth;

        double x = Math.random() * (palletWidth - boxWidth); // Random x within the pallet
        double y = Math.random() * (palletDepth - boxDepth); // Random y within the pallet

        if (!isColliding(x, y, boxWidth, boxDepth, currentLayer) &&
            !isOutOfBounds(x, y, boxWidth, boxDepth, palletWidth, palletDepth)) {
            placedBoxesPerLayer.get(currentLayer).add(new BoxPosition(x, y, boxWidth, boxDepth, currentLayer));

            Rectangle boxRect = createDraggableBox(x, y, boxWidth, boxDepth);
            palletPane.getChildren().add(boxRect);
        } else {
            statusLabel.setText("Cannot add box. Adjust placement or box dimensions.");
        }
    }
    
    private void addLayer() {
        if (!isBuilding) {
            statusLabel.setText("Start building before adding layers.");
            return;
        }
        


        // If currentLayer is valid, save the current layer's boxes
        if (currentLayer >= 0 && currentLayer < placedBoxesPerLayer.size()) {
            // The current layer should not be added again
            placedBoxesPerLayer.set(currentLayer, new ArrayList<>(placedBoxesPerLayer.get(currentLayer)));
        }

        // Move to the next layer
        currentLayer++;
        // Initialize a new empty layer
        placedBoxesPerLayer.add(new ArrayList<>());
        // Clear the pallet pane for the new layer
        palletPane.getChildren().clear();
        statusLabel.setText("Layer " + (currentLayer + 1) + " added. Place boxes for this layer.");
    }

    private void finishLayer() {
        if (!isBuilding) {
            statusLabel.setText("Start building before finishing layers.");
            return;
        }

        // If currentLayer is valid, save the current layer's boxes
        if (currentLayer >= 0 && currentLayer < placedBoxesPerLayer.size()) {
            // Ensure we don’t save an empty layer
            if (!placedBoxesPerLayer.get(currentLayer).isEmpty()) {
                placedBoxesPerLayer.set(currentLayer, new ArrayList<>(placedBoxesPerLayer.get(currentLayer)));
            }
        }

        // Clear the pallet pane for the next layer
        palletPane.getChildren().clear();
        statusLabel.setText("Layer " + (currentLayer + 1) + " completed. Ready for the next layer or to finalize.");
    }

    private void confirmPlacements() {
        StringBuilder pattern = new StringBuilder("Pattern:\n");

        for (int layer = 0; layer < placedBoxesPerLayer.size(); layer++) {
            List<BoxPosition> layerBoxes = placedBoxesPerLayer.get(layer);
            pattern.append("Layer ").append(layer + 1).append(":\n");

            for (BoxPosition box : layerBoxes) {
                pattern.append(String.format("Box at (%.2f, %.2f)%n", box.getX(), box.getY()));
            }
        }

        statusLabel.setText(pattern.toString());
        // Send box placement pattern to robot
        robotController.sendPattern(pattern.toString());
    }
    
    /*
    private Rectangle createDraggableBox(double x, double y, double width, double depth) {
        Rectangle box = new Rectangle(x, y, width, depth);
        box.setFill(Color.BLUE);
        box.setStroke(Color.BLACK);
        box.setStrokeWidth(1);

        box.setOnMousePressed(event -> {
            // Record the initial position of the mouse and box
            box.setUserData(new double[]{event.getX(), event.getY(), box.getX(), box.getY()});
        });

        box.setOnMouseDragged(event -> {
            double[] data = (double[]) box.getUserData();
            double dx = event.getX() - data[0];
            double dy = event.getY() - data[1];
            
            double newX = data[2] + dx;
            double newY = data[3] + dy;

            // Check for collisions and gaps during dragging
            boolean collision = isColliding(newX, newY, width, depth, currentLayer);
            boolean outOfBounds = isOutOfBounds(newX, newY, width, depth, mainApp.getPalletWidth(), mainApp.getPalletDepth());
            
            if (collision) {
                statusLabel.setText("Collision detected or gap too small. Adjust the box position.");
            } else if (outOfBounds) {
                statusLabel.setText("Box out of bounds. Adjust the box position.");
            } else {
                box.setX(newX);
                box.setY(newY);
                statusLabel.setText(""); // Clear status if no issues
            }
        });
        
        box.setOnTouchPressed(event -> {
            double touchX = event.getTouchPoint().getX();
            double touchY = event.getTouchPoint().getY();
            box.setUserData(new double[]{touchX, touchY, box.getX(), box.getY()});
        });

        box.setOnTouchMoved(event -> {
            double touchX = event.getTouchPoint().getX();
            double touchY = event.getTouchPoint().getY();
            double[] data = (double[]) box.getUserData();
            double dx = touchX - data[0];
            double dy = touchY - data[1];

            double newX = data[2] + dx;
            double newY = data[3] + dy;

            // Check for collisions and gaps during dragging
            boolean collision = isColliding(newX, newY, width, depth, currentLayer);
            boolean outOfBounds = isOutOfBounds(newX, newY, width, depth, mainApp.getPalletWidth(), mainApp.getPalletDepth());

            if (collision) {
                statusLabel.setText("Collision detected or gap too small. Adjust the box position.");
            } else if (outOfBounds) {
                statusLabel.setText("Box out of bounds. Adjust the box position.");
            } else {
                box.setX(newX);
                box.setY(newY);
                statusLabel.setText(""); // Clear status if no issues
            }
        });

        return box;
    }
    */
    
    private Rectangle createDraggableBox(double x, double y, double width, double depth) {
        Rectangle box = new Rectangle(x, y, width, depth);
        box.setFill(Color.BLUE);
        box.setStroke(Color.BLACK);
        box.setStrokeWidth(1);

        // Store the initial position and size of the box
        box.setOnMousePressed(event -> {
            box.setUserData(new double[]{event.getX(), event.getY(), box.getX(), box.getY()});
        });

        // Handle dragging of the box
        box.setOnMouseDragged(event -> {
            double[] data = (double[]) box.getUserData();
            double dx = event.getX() - data[0];
            double dy = event.getY() - data[1];

            double newX = data[2] + dx;
            double newY = data[3] + dy;

            // Check for collisions and out of bounds
            if (!isColliding(newX, newY, width, depth, currentLayer) &&
                !isOutOfBounds(newX, newY, width, depth, mainApp.getPalletWidth(), mainApp.getPalletDepth())) {
                
                // Update box position if no collisions
                box.setX(newX);
                box.setY(newY);
            } else {
                // Notify user of collision or out of bounds
                statusLabel.setText("Cannot move box. Adjust placement to avoid collisions or stay within bounds.");
            }
        });

        // Handle touch events for draggable box
        box.setOnTouchPressed(event -> {
            double touchX = event.getTouchPoint().getX();
            double touchY = event.getTouchPoint().getY();
            box.setUserData(new double[]{touchX, touchY, box.getX(), box.getY()});
        });

        box.setOnTouchMoved(event -> {
            double touchX = event.getTouchPoint().getX();
            double touchY = event.getTouchPoint().getY();
            double[] data = (double[]) box.getUserData();
            double dx = touchX - data[0];
            double dy = touchY - data[1];

            double newX = data[2] + dx;
            double newY = data[3] + dy;

            // Check for collisions and out of bounds
            if (!isColliding(newX, newY, width, depth, currentLayer) &&
                !isOutOfBounds(newX, newY, width, depth, mainApp.getPalletWidth(), mainApp.getPalletDepth())) {
                
                // Update box position if no collisions
                box.setX(newX);
                box.setY(newY);
            } else {
                // Notify user of collision or out of bounds
                statusLabel.setText("Cannot move box. Adjust placement to avoid collisions or stay within bounds.");
            }
        });

        return box;
    }

    
    private boolean isColliding(double x, double y, double width, double depth, int layer) {
        for (BoxPosition existingBox : placedBoxesPerLayer.get(layer)) {
            if (x < existingBox.getX() + existingBox.getWidth() + gapSize &&
                x + width > existingBox.getX() - gapSize &&
                y < existingBox.getY() + existingBox.getDepth() + gapSize &&
                y + depth > existingBox.getY() - gapSize) {
                return true; // Collision detected
            }
        }
        return false;
    }

    /*
    private boolean isOutOfBounds(double x, double y, double width, double depth, double palletWidth, double palletDepth) {
        return x < 0 || x + width > palletWidth || y < 0 || y + depth > palletDepth;
    }
    */
    
    private boolean isOutOfBounds(double x, double y, double width, double depth, double palletWidth, double palletDepth) {
        System.out.println("Box Position: (" + x + ", " + y + ")");
        System.out.println("Box Dimensions: Width=" + width + ", Depth=" + depth);
        System.out.println("Pallet Dimensions: Width=" + palletWidth + ", Depth=" + palletDepth);
        
        boolean outOfBounds = x < 0 || x + width > palletWidth || y < 0 || y + depth > palletDepth;
        
        if (outOfBounds) {
            System.out.println("Box is out of bounds.");
        }
        
        return outOfBounds;
    }

    
    private void handlePress(MouseEvent event) {
        // Handle mouse press events
        double x = event.getX();
        double y = event.getY();
        // Implement the logic to start dragging or interacting with boxes
    }

    private void handleDrag(MouseEvent event) {
        // Handle mouse drag events
        double x = event.getX();
        double y = event.getY();
        // Implement the logic to drag boxes
    }

    private void handleTouch(TouchEvent event) {
        // Handle touch events
        double x = event.getTouchPoint().getX();
        double y = event.getTouchPoint().getY();
        // Implement the logic to start dragging or interacting with boxes
    }

}

    class BoxPosition {
        private double x;
        private double y;
        private double width;
        private double depth;
        private int layer;

        public BoxPosition(double x, double y, double width, double depth, int layer) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.depth = depth;
            this.layer = layer;
        }

        public double getX() {
            return x;
        }

        public double getY() {
            return y;
        }

        public double getWidth() {
            return width;
        }

        public double getDepth() {
            return depth;
        }

        public int getLayer() {
            return layer;
        }
    }

 // Inner class to represent the input fields for box positions
    class BoxInput {
        TextField xField;
        TextField yField;

        BoxInput() {
            xField = new TextField();
            yField = new TextField();
        }
    }