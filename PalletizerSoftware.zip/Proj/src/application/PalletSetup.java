package application;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class PalletSetup extends GridPane {

    private TextField boxWidthField;
    private TextField boxHeightField;
    private TextField boxDepthField;
    private TextField palletWidthField;
    private TextField palletHeightField;
    private TextField palletDepthField;
    private Label statusLabel;
    private Button saveButton;
    private Main mainApp;
    private ComboBox<Integer> slipsheetCountDropdown;
   // private ComboBox<Integer> layerCountDropdown;

    public PalletSetup(String title, Main mainApp) {
        this.mainApp = mainApp;

        setPadding(new Insets(10));
        setHgap(10);
        setVgap(10);

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        boxWidthField = new TextField();
        boxHeightField = new TextField();
        boxDepthField = new TextField();
        palletWidthField = new TextField();
        palletHeightField = new TextField();
        palletDepthField = new TextField();
        slipsheetCountDropdown = new ComboBox<>();

        /*
        layerCountDropdown = new ComboBox<>();
        for (int i = 1; i <= 8; i++) {
            layerCountDropdown.getItems().add(i);
        }
        layerCountDropdown.setValue(1); // Default value
        */
        
        // Populate ComboBox with numbers 0-8 for total number of slip sheets
        for (int i = 0; i <= 8; i++) {
        	slipsheetCountDropdown.getItems().add(i);
        }

        // Set default value for ComboBox
        slipsheetCountDropdown.setValue(0);
        

        saveButton = new Button("Save Setup");
        saveButton.setOnAction(e -> handleSaveSetup());

        statusLabel = new Label();

        /*
        add(titleLabel, 0, 0, 2, 1);
        add(new Label("Box Width:"), 0, 1);
        add(boxWidthField, 1, 1);
        add(new Label("Box Height:"), 0, 2);
        add(boxHeightField, 1, 2);
        add(new Label("Box Depth:"), 0, 3);
        add(boxDepthField, 1, 3);
        add(new Label("Pallet Width:"), 0, 4);
        add(palletWidthField, 1, 4);
        add(new Label("Pallet Height:"), 0, 5);
        add(palletHeightField, 1, 5);
        add(new Label("Pallet Depth:"), 0, 6);
        add(palletDepthField, 1, 6);
        add(saveButton, 0, 7, 2, 1);
        add(statusLabel, 0, 8, 2, 1);
        */
        
        add(titleLabel, 0, 0, 2, 1);
        add(new Label("Box Width:"), 0, 1);
        add(boxWidthField, 1, 1);
        add(new Label("Box Height:"), 0, 2);
        add(boxHeightField, 1, 2);
        add(new Label("Box Depth:"), 0, 3);
        add(boxDepthField, 1, 3);
        add(new Label("Pallet Width:"), 0, 4);
        add(palletWidthField, 1, 4);
        add(new Label("Pallet Height:"), 0, 5);
        add(palletHeightField, 1, 5);
        add(new Label("Pallet Depth:"), 0, 6);
        add(palletDepthField, 1, 6);
        //add(new Label("Number of Layers:"), 0, 7);
        //add(layerCountDropdown, 1, 7);
        add(new Label("Total Slip Sheets:"), 0, 8);
        add(slipsheetCountDropdown, 1, 8);
        add(saveButton, 0, 9, 2, 1);
        add(statusLabel, 0, 10, 2, 1);
    }

    private void handleSaveSetup() {
        try {
            double boxWidth = Double.parseDouble(boxWidthField.getText());
            double boxHeight = Double.parseDouble(boxHeightField.getText());
            double boxDepth = Double.parseDouble(boxDepthField.getText());
            double palletWidth = Double.parseDouble(palletWidthField.getText());
            double palletHeight = Double.parseDouble(palletHeightField.getText());
            double palletDepth = Double.parseDouble(palletDepthField.getText());
           // int numberOfLayers = layerCountDropdown.getValue();
            int numberOfSlipsheets = slipsheetCountDropdown.getValue();

            mainApp.setBoxDimensions(boxWidth, boxHeight, boxDepth);
            mainApp.setPalletDimensions(palletWidth, palletHeight, palletDepth);
            //mainApp.setNumberOfLayers(numberOfLayers);
            mainApp.setNumberOfSlipsheets(numberOfSlipsheets);

            statusLabel.setText("Setup saved successfully.");

        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid input. Please enter valid numbers.");
        }
    }
}


/*
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class PalletSetup {
    private VBox pane;
    private TextField boxWidthField;
    private TextField boxHeightField;
    private TextField boxDepthField;
    private TextField palletWidthField;
    private TextField palletHeightField;
    private TextField palletDepthField;

    public PalletSetup() {
        pane = new VBox();

        boxWidthField = new TextField();
        boxHeightField = new TextField();
        boxDepthField = new TextField();
        palletWidthField = new TextField();
        palletHeightField = new TextField();
        palletDepthField = new TextField();

        pane.getChildren().addAll(
            new Label("Box Width:"), boxWidthField,
            new Label("Box Height:"), boxHeightField,
            new Label("Box Depth:"), boxDepthField,
            new Label("Pallet Width:"), palletWidthField,
            new Label("Pallet Height:"), palletHeightField,
            new Label("Pallet Depth:"), palletDepthField
        );
    }

    public VBox getPane() {
        return pane;
    }

    // Getters for dimensions to use in other classes
    public double getBoxWidth() {
        return Double.parseDouble(boxWidthField.getText());
    }

    public double getBoxHeight() {
        return Double.parseDouble(boxHeightField.getText());
    }

    public double getBoxDepth() {
        return Double.parseDouble(boxDepthField.getText());
    }

    public double getPalletWidth() {
        return Double.parseDouble(palletWidthField.getText());
    }

    public double getPalletHeight() {
        return Double.parseDouble(palletHeightField.getText());
    }

    public double getPalletDepth() {
        return Double.parseDouble(palletDepthField.getText());
    }
}
*/