package application;
/*
import java.util.Arrays;
import java.util.HashSet;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;

public class Controller {

    @FXML
    private TextField controllerIdField;
    
    @FXML
    private TextField hostnameField;
    
    @FXML
    private TextField jobNameField;
    
    @FXML
    private Button moveButton;

    private String controllerID;
    private String hostname;
    private String jobName;

    // Initialization method
    @FXML
    public void initialize() {
        // Initialization logic, if any
    }

    // Method to handle the move button action
    @FXML
    public void handleMoveButtonAction() {
        controllerID = controllerIdField.getText();
        hostname = hostnameField.getText();
        jobName = jobNameField.getText();

        // Define a sample position (this should be dynamic based on your UI inputs)
        Position position = new Position(100, 200, 300, 0, 0, 0); // Example values

        moveToPosition(controllerID, hostname, jobName, position);
    }

    // Method to connect and move the robot
    public void moveToPosition(String controllerID, String hostname, String jobName, Position position) {
        try {
            // Connect to the controller
            Controller.connect(controllerID, hostname);

            // Request permissions
            Controller.requestPermissions(controllerID, new HashSet<>(Arrays.asList("jobcontrol")));

            // Ensure the controller is ready
            boolean isConnected = Controller.connected(controllerID);
            boolean hasExclusiveControl = Controller.haveExclusiveControl(controllerID);
            ServoState servoState = Controller.servoState(controllerID);
            OperationMode operationMode = Controller.operationMode(controllerID);

            if (isConnected && hasExclusiveControl && servoState == ServoState.On && operationMode == OperationMode.Automatic) {
                // Check if the job exists
                if (Controller.jobExists(controllerID, jobName)) {
                    // Set and run the job
                    Controller.setCurrentJob(controllerID, jobName, 1);
                    Controller.run(controllerID);
                } else {
                    System.out.println("Job does not exist: " + jobName);
                }

                // Alternatively, move directly to a position
                // Controller.moveTo(controllerID, position);
            } else {
                System.out.println("Controller is not ready for motion");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/

