java -cp dependencies/yaskawa-ext-2.0.4.jar:dependencies/libthrift-0.11.0.jar:dependencies/slf4j-api.jar:dependencies/slf4j-simple.jar:DemoExtension.jar:. DemoExtension $1 $2
