javac -cp ../../../../External/thrift/lib/java/build/libthrift-0.11.0.jar:/usr/share/java/slf4j-api.jar:../../java/yaskawa-ext-0.1.3-pre.jar LogWatch.java
jar -cfe LogWatch.jar LogWatch LogWatch.class

