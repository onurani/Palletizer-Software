#! /bin/bash
cd docs/en
thrift --gen html ../../extension.thrift

