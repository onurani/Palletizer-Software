java -cp ../java/yaskawa-ext-2.0.4.jar:../../../External/thrift/lib/java/build/libthrift-0.11.0.jar:/usr/share/java/slf4j-api.jar:/usr/share/java/slf4j-simple.jar:Calculator.jar:. Calculator $1 $2
